export interface Catalogue {
  id: string;
  name: string;
  artist: string;
  genre: string;
  tracks: number;
  historicalRevenue: {
    year: number;
    amount: number;
  }[];
  targetAmount: number;
  raisedAmount: number;
  minimumInvestment: number;
  spvName: string;
  status: "open" | "funding" | "closed";
  imageUrl: string;
  description: string;
  highlights: string[];
}

export const catalogues: Catalogue[] = [
  {
    id: "cat-001",
    name: "Collection Électronique Parisienne",
    artist: "DJ Laurent",
    genre: "Électronique",
    tracks: 247,
    historicalRevenue: [
      { year: 2020, amount: 185000 },
      { year: 2021, amount: 210000 },
      { year: 2022, amount: 245000 },
      { year: 2023, amount: 278000 },
      { year: 2024, amount: 312000 },
    ],
    targetAmount: 2500000,
    raisedAmount: 1875000,
    minimumInvestment: 5000,
    spvName: "Harmonia SPV Électro I",
    status: "funding",
    imageUrl: "/catalogues/electronic.jpg",
    description:
      "Un catalogue emblématique de musique électronique française couvrant 15 années de production. Inclut des succès diffusés dans plus de 40 pays.",
    highlights: [
      "247 titres originaux",
      "Diffusé dans 40+ pays",
      "15 ans de catalogue",
      "Revenus stables depuis 2018",
    ],
  },
  {
    id: "cat-002",
    name: "Héritage Jazz Classique",
    artist: "Trio Montmartre",
    genre: "Jazz",
    tracks: 156,
    historicalRevenue: [
      { year: 2020, amount: 95000 },
      { year: 2021, amount: 102000 },
      { year: 2022, amount: 118000 },
      { year: 2023, amount: 125000 },
      { year: 2024, amount: 138000 },
    ],
    targetAmount: 1200000,
    raisedAmount: 1200000,
    minimumInvestment: 3000,
    spvName: "Harmonia SPV Jazz II",
    status: "closed",
    imageUrl: "/catalogues/jazz.jpg",
    description:
      "Collection de jazz classique français avec des enregistrements historiques et des compositions originales du célèbre Trio Montmartre.",
    highlights: [
      "156 enregistrements",
      "Classiques du jazz français",
      "Utilisé dans 25+ films",
      "Droits synchronisation inclus",
    ],
  },
  {
    id: "cat-003",
    name: "Pop Française Moderne",
    artist: "Marie & Les Étoiles",
    genre: "Pop",
    tracks: 89,
    historicalRevenue: [
      { year: 2020, amount: 320000 },
      { year: 2021, amount: 385000 },
      { year: 2022, amount: 412000 },
      { year: 2023, amount: 445000 },
      { year: 2024, amount: 498000 },
    ],
    targetAmount: 4000000,
    raisedAmount: 2800000,
    minimumInvestment: 10000,
    spvName: "Harmonia SPV Pop III",
    status: "funding",
    imageUrl: "/catalogues/pop.jpg",
    description:
      "Catalogue de pop française contemporaine avec plusieurs titres certifiés platine. Forte présence streaming et radio.",
    highlights: [
      "3 titres platine",
      "500M+ streams",
      "Présence radio majeure",
      "Artiste en activité",
    ],
  },
  {
    id: "cat-004",
    name: "Catalogue Hip-Hop Urbain",
    artist: "Collectif 93",
    genre: "Hip-Hop",
    tracks: 312,
    historicalRevenue: [
      { year: 2020, amount: 520000 },
      { year: 2021, amount: 615000 },
      { year: 2022, amount: 698000 },
      { year: 2023, amount: 785000 },
      { year: 2024, amount: 892000 },
    ],
    targetAmount: 6000000,
    raisedAmount: 1500000,
    minimumInvestment: 15000,
    spvName: "Harmonia SPV Urban IV",
    status: "open",
    imageUrl: "/catalogues/hiphop.jpg",
    description:
      "Collection majeure de hip-hop français incluant des collaborations avec des artistes internationaux. Forte croissance streaming.",
    highlights: [
      "312 titres",
      "Collabs internationales",
      "1.2B+ streams totaux",
      "Croissance +15%/an",
    ],
  },
  {
    id: "cat-005",
    name: "Musique de Film Française",
    artist: "Orchestre Symphonique de Lyon",
    genre: "Classique/Film",
    tracks: 78,
    historicalRevenue: [
      { year: 2020, amount: 145000 },
      { year: 2021, amount: 168000 },
      { year: 2022, amount: 189000 },
      { year: 2023, amount: 215000 },
      { year: 2024, amount: 248000 },
    ],
    targetAmount: 1800000,
    raisedAmount: 450000,
    minimumInvestment: 5000,
    spvName: "Harmonia SPV Ciné V",
    status: "open",
    imageUrl: "/catalogues/cinema.jpg",
    description:
      "Bandes originales de films français primés. Inclut des compositions utilisées dans des productions Netflix et Amazon.",
    highlights: [
      "78 compositions",
      "12 films primés",
      "Netflix & Amazon",
      "Droits mondiaux",
    ],
  },
];

export interface PricingTier {
  id: string;
  name: string;
  price: number;
  period: string;
  description: string;
  features: string[];
  highlighted: boolean;
  maxInvestmentPerYear: string;
  maxInvestmentPerCatalogue: string;
  dealFee: string;
}

export const pricingTiers: PricingTier[] = [
  {
    id: "tier-essential",
    name: "Essential",
    price: 1000,
    period: "an",
    description: "L'accès aux fondamentaux de l'investissement musical",
    features: [
      "Accès aux catalogues",
      "Dashboard investisseur",
      "Analyses de catalogues",
      "Communauté privée",
    ],
    highlighted: false,
    maxInvestmentPerYear: "10 000 €",
    maxInvestmentPerCatalogue: "2 000 €",
    dealFee: "5%",
  },
  {
    id: "tier-premium",
    name: "Premium",
    price: 3000,
    period: "an",
    description: "Pour les investisseurs ambitieux avec accès prioritaire",
    features: [
      "Tout Essential",
      "Accès anticipé",
      "Priorité allocation",
      "Événements privés",
      "Analyses avancées",
    ],
    highlighted: true,
    maxInvestmentPerYear: "50 000 €",
    maxInvestmentPerCatalogue: "15 000 €",
    dealFee: "4%",
  },
  {
    id: "tier-black",
    name: "Black",
    price: 10000,
    period: "an",
    description: "L'expérience ultime pour les investisseurs d'exception",
    features: [
      "Tout Premium",
      "Catalogues exclusifs",
      "Rencontres artistes et producteurs",
      "Accès équipe Harmonia",
      "Networking premium",
    ],
    highlighted: false,
    maxInvestmentPerYear: "Illimité",
    maxInvestmentPerCatalogue: "100 000 €+",
    dealFee: "3%",
  },
];

export interface InvestorStats {
  totalInvested: number;
  totalCatalogues: number;
  historicalReturns: number;
  pendingDistributions: number;
}

export interface Investment {
  id: string;
  catalogueId: string;
  catalogueName: string;
  investedAmount: number;
  investmentDate: string;
  ownership: number;
  distributions: {
    date: string;
    amount: number;
  }[];
}

export const mockInvestorData: {
  stats: InvestorStats;
  investments: Investment[];
} = {
  stats: {
    totalInvested: 125000,
    totalCatalogues: 4,
    historicalReturns: 18750,
    pendingDistributions: 3200,
  },
  investments: [
    {
      id: "inv-001",
      catalogueId: "cat-001",
      catalogueName: "Collection Électronique Parisienne",
      investedAmount: 50000,
      investmentDate: "2023-03-15",
      ownership: 2.0,
      distributions: [
        { date: "2023-06-30", amount: 1500 },
        { date: "2023-12-31", amount: 1800 },
        { date: "2024-06-30", amount: 2100 },
        { date: "2024-12-31", amount: 2400 },
      ],
    },
    {
      id: "inv-002",
      catalogueId: "cat-002",
      catalogueName: "Héritage Jazz Classique",
      investedAmount: 25000,
      investmentDate: "2023-06-01",
      ownership: 2.08,
      distributions: [
        { date: "2023-12-31", amount: 650 },
        { date: "2024-06-30", amount: 720 },
        { date: "2024-12-31", amount: 780 },
      ],
    },
    {
      id: "inv-003",
      catalogueId: "cat-003",
      catalogueName: "Pop Française Moderne",
      investedAmount: 35000,
      investmentDate: "2024-01-10",
      ownership: 0.875,
      distributions: [
        { date: "2024-06-30", amount: 2200 },
        { date: "2024-12-31", amount: 2600 },
      ],
    },
    {
      id: "inv-004",
      catalogueId: "cat-004",
      catalogueName: "Catalogue Hip-Hop Urbain",
      investedAmount: 15000,
      investmentDate: "2024-09-01",
      ownership: 0.25,
      distributions: [{ date: "2024-12-31", amount: 1000 }],
    },
  ],
};

export interface AdminStats {
  totalAUM: number;
  totalInvestors: number;
  activeCatalogues: number;
  pendingApplications: number;
  monthlyGrowth: number;
}

export const mockAdminStats: AdminStats = {
  totalAUM: 15750000,
  totalInvestors: 847,
  activeCatalogues: 5,
  pendingApplications: 23,
  monthlyGrowth: 8.5,
};
