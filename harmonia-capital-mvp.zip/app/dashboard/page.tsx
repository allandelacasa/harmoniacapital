"use client";

import Link from "next/link";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { StatCard } from "@/components/stat-card";
import { ProgressBar } from "@/components/progress-bar";
import { mockInvestorData, catalogues } from "@/lib/data";
import { motion } from "framer-motion";
import {
  Briefcase,
  TrendingUp,
  Wallet,
  Music2,
  ArrowUpRight,
  Calendar,
  Download,
  Disc3,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";

export default function DashboardPage() {
  const { stats, investments } = mockInvestorData;

  const distributionData = investments.map((inv) => ({
    name: inv.catalogueName.split(" ").slice(0, 2).join(" "),
    distributions: inv.distributions.reduce((sum, d) => sum + d.amount, 0),
  }));

  const portfolioEvolution = [
    { month: "Jan", value: 95000 },
    { month: "Fév", value: 98000 },
    { month: "Mar", value: 105000 },
    { month: "Avr", value: 108000 },
    { month: "Mai", value: 112000 },
    { month: "Juin", value: 118000 },
    { month: "Juil", value: 120000 },
    { month: "Août", value: 122000 },
    { month: "Sep", value: 125000 },
    { month: "Oct", value: 128000 },
    { month: "Nov", value: 132000 },
    { month: "Déc", value: 143750 },
  ];

  return (
    <div className="min-h-screen bg-background grain">
      <Header />

      <main className="pt-28 pb-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-center"
          >
            <div>
              <span className="sticker mb-2 inline-block">MON ESPACE</span>
              <h1 className="text-display text-3xl sm:text-4xl">
                DASHBOARD
              </h1>
              <p className="mt-2 text-muted-foreground">
                Salut Jean-Pierre. Voici ton portefeuille.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 glass-card rounded-full px-5 py-2.5 text-sm font-medium transition-all hover:bg-white/10">
                <Download className="h-4 w-4" />
                Export
              </button>
              <Link
                href="/catalogues"
                className="group flex items-center gap-2 bg-primary text-primary-foreground rounded-full px-5 py-2.5 text-sm font-bold hover:shadow-[0_0_20px_rgba(132,204,22,0.3)] transition-all"
              >
                Investir
                <ArrowUpRight className="h-4 w-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </Link>
            </div>
          </motion.div>

          {/* Stats */}
          <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              label="Total investi"
              value={new Intl.NumberFormat("fr-FR", {
                style: "currency",
                currency: "EUR",
                maximumFractionDigits: 0,
              }).format(stats.totalInvested)}
              icon={<Briefcase className="h-5 w-5" />}
              glowColor="neon"
            />
            <StatCard
              label="Revenus perçus"
              value={new Intl.NumberFormat("fr-FR", {
                style: "currency",
                currency: "EUR",
                maximumFractionDigits: 0,
              }).format(stats.historicalReturns)}
              change="+12.5% vs année précédente"
              changeType="positive"
              icon={<TrendingUp className="h-5 w-5" />}
              glowColor="neon"
            />
            <StatCard
              label="À venir"
              value={new Intl.NumberFormat("fr-FR", {
                style: "currency",
                currency: "EUR",
                maximumFractionDigits: 0,
              }).format(stats.pendingDistributions)}
              change="Prochaine : Juin 2025"
              changeType="neutral"
              icon={<Wallet className="h-5 w-5" />}
              glowColor="purple"
            />
            <StatCard
              label="Catalogues"
              value={stats.totalCatalogues.toString()}
              icon={<Music2 className="h-5 w-5" />}
              glowColor="purple"
            />
          </div>

          {/* Charts */}
          <div className="mb-8 grid gap-6 lg:grid-cols-2">
            {/* Portfolio evolution */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="glass-card rounded-2xl p-6"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-bold">Évolution du portefeuille</h2>
                <span className="sticker text-[10px]">2024</span>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={portfolioEvolution}>
                    <defs>
                      <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="oklch(0.85 0.25 145)" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="oklch(0.85 0.25 145)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 280)" vertical={false} />
                    <XAxis dataKey="month" stroke="oklch(0.55 0 0)" fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis stroke="oklch(0.55 0 0)" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "oklch(0.1 0.01 280)",
                        border: "1px solid oklch(0.25 0.02 280)",
                        borderRadius: "12px",
                      }}
                      labelStyle={{ color: "oklch(0.98 0 0)", fontWeight: "bold" }}
                      formatter={(value: number) => [
                        new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(value),
                        "Valeur",
                      ]}
                    />
                    <Area type="monotone" dataKey="value" stroke="oklch(0.85 0.25 145)" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            {/* Distributions by catalogue */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-card rounded-2xl p-6"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-bold">Revenus par catalogue</h2>
                <span className="sticker-purple text-[10px]">HISTORIQUE</span>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={distributionData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 280)" horizontal={false} />
                    <XAxis type="number" stroke="oklch(0.55 0 0)" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`} />
                    <YAxis dataKey="name" type="category" stroke="oklch(0.55 0 0)" fontSize={10} width={80} tickLine={false} axisLine={false} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "oklch(0.1 0.01 280)",
                        border: "1px solid oklch(0.25 0.02 280)",
                        borderRadius: "12px",
                      }}
                      labelStyle={{ color: "oklch(0.98 0 0)", fontWeight: "bold" }}
                      formatter={(value: number) => [
                        new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(value),
                        "Revenus",
                      ]}
                    />
                    <Bar dataKey="distributions" fill="oklch(0.7 0.2 300)" radius={[0, 6, 6, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          </div>

          {/* Investments list */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="glass-card rounded-2xl overflow-hidden"
          >
            <div className="border-b border-border/50 p-6 flex items-center justify-between">
              <h2 className="font-bold">Mes investissements</h2>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Disc3 className="h-4 w-4" />
                <span className="text-sm">{investments.length} actifs</span>
              </div>
            </div>
            <div className="divide-y divide-border/50">
              {investments.map((investment, index) => {
                const catalogue = catalogues.find((c) => c.id === investment.catalogueId);
                const totalDistributions = investment.distributions.reduce((sum, d) => sum + d.amount, 0);

                return (
                  <motion.div
                    key={investment.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 + index * 0.05 }}
                    className="p-6 transition-colors hover:bg-white/[0.02]"
                  >
                    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                      <div className="flex-1">
                        <Link
                          href={`/catalogues/${investment.catalogueId}`}
                          className="font-bold hover:text-primary transition-colors inline-flex items-center gap-2 group"
                        >
                          {investment.catalogueName}
                          <ArrowUpRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </Link>
                        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3.5 w-3.5" />
                            {new Date(investment.investmentDate).toLocaleDateString("fr-FR")}
                          </span>
                          <span className="text-primary font-medium">{investment.ownership}%</span>
                          {catalogue && (
                            <span className="sticker text-[9px] scale-90">{catalogue.genre}</span>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-6 text-right sm:gap-8">
                        <div>
                          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Investi</p>
                          <p className="font-bold">
                            {new Intl.NumberFormat("fr-FR", {
                              style: "currency",
                              currency: "EUR",
                              maximumFractionDigits: 0,
                            }).format(investment.investedAmount)}
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Revenus</p>
                          <p className="font-bold text-primary">
                            {new Intl.NumberFormat("fr-FR", {
                              style: "currency",
                              currency: "EUR",
                              maximumFractionDigits: 0,
                            }).format(totalDistributions)}
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Distributions</p>
                          <p className="font-bold">{investment.distributions.length}</p>
                        </div>
                      </div>
                    </div>

                    {catalogue && (
                      <div className="mt-4">
                        <ProgressBar
                          value={totalDistributions}
                          max={investment.investedAmount * 0.2}
                          size="sm"
                          showLabel={false}
                          variant="purple"
                        />
                        <p className="mt-1.5 text-xs text-muted-foreground">
                          Revenus cumulés : <span className="text-accent font-medium">{((totalDistributions / investment.investedAmount) * 100).toFixed(1)}%</span> du capital
                        </p>
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          </motion.div>

          {/* Disclaimer */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-8 glass-card rounded-xl p-4"
          >
            <p className="text-xs text-muted-foreground text-center">
              Les valeurs affichées sont basées sur les dernières données disponibles.
              Les revenus passés ne préjugent pas des revenus futurs.
            </p>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
