"use client";

import Link from "next/link";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { CatalogueCard } from "@/components/catalogue-card";
import { StatCard } from "@/components/stat-card";
import { catalogues } from "@/lib/data";
import { motion } from "framer-motion";
import {
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  Shield,
  Music2,
  TrendingUp,
  Users,
  Briefcase,
  Disc3,
  Zap,
  Sparkles,
} from "lucide-react";

export default function HomePage() {
  const featuredCatalogues = catalogues.filter((c) => c.status !== "closed").slice(0, 3);

  return (
    <div className="min-h-screen bg-background grain">
      <Header />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 -z-10 gradient-mesh" />
        
        {/* Floating disc elements */}
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
            className="absolute -right-32 top-20 opacity-10"
          >
            <Disc3 className="h-96 w-96 text-primary" />
          </motion.div>
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
            className="absolute -left-20 bottom-20 opacity-5"
          >
            <Disc3 className="h-72 w-72 text-accent" />
          </motion.div>
        </div>

        <div className="mx-auto max-w-7xl px-6 lg:px-8 pt-32 pb-20">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              {/* Badge */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="inline-flex items-center gap-2 mb-8"
              >
                <span className="sticker">CLUB EXCLUSIF</span>
                <span className="sticker-purple">MUSIC x FINANCE</span>
              </motion.div>

              {/* Headline */}
              <h1 className="text-display text-5xl sm:text-6xl lg:text-7xl">
                <span className="block">INVESTIS</span>
                <span className="block">DANS LA</span>
                <span className="block text-primary text-glow-neon">CULTURE</span>
              </h1>

              <p className="mt-8 text-lg text-muted-foreground max-w-lg leading-relaxed">
                Harmonia Capital te donne accès aux catalogues musicaux les plus 
                exclusifs. Rejoins le club et perçois les revenus des droits via des SPV dédiés.
              </p>

              {/* CTAs */}
              <div className="mt-10 flex flex-wrap items-center gap-4">
                <Link
                  href="/catalogues"
                  className="group flex items-center gap-3 bg-primary text-primary-foreground px-8 py-4 rounded-full text-base font-bold hover:shadow-[0_0_30px_rgba(132,204,22,0.3)] transition-all"
                >
                  Explorer les drops
                  <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link
                  href="/pricing"
                  className="group flex items-center gap-3 glass px-8 py-4 rounded-full text-base font-bold hover:bg-white/10 transition-all"
                >
                  Rejoindre
                  <ArrowUpRight className="h-5 w-5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </Link>
              </div>

              {/* Disclaimer */}
              <div className="mt-10 glass-card rounded-xl p-4 max-w-lg">
                <p className="text-xs text-muted-foreground">
                  Les performances passées ne garantissent pas les résultats futurs. 
                  Capital non garanti. Investissement réservé aux membres du club.
                </p>
              </div>
            </motion.div>

            {/* Right - Floating cards preview */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="relative hidden lg:block"
            >
              <div className="relative h-[600px]">
                {/* Floating catalogue cards */}
                <motion.div
                  animate={{ y: [0, -15, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute top-0 left-0 w-72"
                >
                  <div className="glass-card rounded-2xl p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                        <Disc3 className="h-8 w-8 text-primary" />
                      </div>
                      <div>
                        <p className="text-xs text-primary font-bold">RAP FR</p>
                        <p className="font-bold">Légendes Urbaines</p>
                        <p className="text-sm text-muted-foreground">87% financé</p>
                      </div>
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  animate={{ y: [0, 15, 0] }}
                  transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                  className="absolute top-40 right-0 w-64"
                >
                  <div className="glass-card rounded-2xl p-4 border-accent/30">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-2xl font-bold">+18.5%</p>
                        <p className="text-xs text-muted-foreground">Croissance 2024</p>
                      </div>
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <TrendingUp className="h-6 w-6 text-primary" />
                      </div>
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                  className="absolute bottom-32 left-8 w-56"
                >
                  <div className="glass-card rounded-2xl p-4">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider">Revenus distribués</p>
                    <p className="text-3xl font-bold mt-1">2.1M€</p>
                    <div className="mt-2 h-1.5 bg-secondary rounded-full overflow-hidden">
                      <div className="h-full w-3/4 bg-gradient-to-r from-primary to-accent rounded-full" />
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  animate={{ y: [0, 12, 0] }}
                  transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 2 }}
                  className="absolute bottom-0 right-8"
                >
                  <div className="sticker text-sm">847 MEMBRES</div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <div className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex justify-center pt-2">
            <div className="w-1 h-2 bg-primary rounded-full" />
          </div>
        </motion.div>
      </section>

      {/* Stats Section */}
      <section className="py-20 relative">
        <div className="absolute inset-0 gradient-radial-neon opacity-30" />
        <div className="mx-auto max-w-7xl px-6 lg:px-8 relative">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <StatCard
              label="Actifs sous gestion"
              value="15.7M€"
              icon={<Briefcase className="h-5 w-5" />}
              glowColor="neon"
            />
            <StatCard
              label="Catalogues"
              value="5"
              change="2 ouverts"
              changeType="positive"
              icon={<Music2 className="h-5 w-5" />}
              glowColor="purple"
            />
            <StatCard
              label="Membres Club"
              value="847"
              change="+127 ce mois"
              changeType="positive"
              icon={<Users className="h-5 w-5" />}
              glowColor="neon"
            />
            <StatCard
              label="Revenus distribués"
              value="2.1M€"
              change="Historique"
              changeType="neutral"
              icon={<BarChart3 className="h-5 w-5" />}
              glowColor="purple"
            />
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-border to-transparent" />
        
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <span className="sticker-purple mb-4 inline-block">LE PROCESS</span>
            <h2 className="text-display text-4xl sm:text-5xl mt-4">
              COMMENT ÇA<br />
              <span className="text-primary">MARCHE</span>
            </h2>
          </motion.div>

          <div className="grid gap-6 md:grid-cols-3">
            {[
              {
                icon: Shield,
                num: "01",
                title: "SPV DÉDIÉ",
                desc: "Chaque catalogue est détenu par une société dédiée. Ton investissement est isolé et transparent.",
              },
              {
                icon: BarChart3,
                num: "02",
                title: "DATA VÉRIFIÉ",
                desc: "Analyse l'historique des revenus avant d'investir. Toutes les données sont auditées.",
              },
              {
                icon: Zap,
                num: "03",
                title: "CASH FLOW",
                desc: "Les droits sont collectés et distribués semestriellement aux investisseurs du SPV.",
              },
            ].map((item, i) => (
              <motion.div
                key={item.num}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-card rounded-2xl p-8 group hover:border-primary/30 transition-all"
              >
                <div className="flex items-start justify-between mb-6">
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                    <item.icon className="h-7 w-7" />
                  </div>
                  <span className="text-5xl font-bold text-muted/30">{item.num}</span>
                </div>
                <h3 className="text-xl font-bold tracking-tight mb-3">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Catalogues */}
      <section className="py-24 relative">
        <div className="absolute inset-0 gradient-radial-purple opacity-20" />
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-accent/50 to-transparent" />
        
        <div className="mx-auto max-w-7xl px-6 lg:px-8 relative">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="sticker mb-4 inline-block">DROPS ACTIFS</span>
              <h2 className="text-display text-4xl sm:text-5xl mt-4">
                CATALOGUES<br />
                <span className="text-accent text-glow-purple">DISPONIBLES</span>
              </h2>
            </motion.div>
            <Link
              href="/catalogues"
              className="group flex items-center gap-2 text-sm font-bold text-primary hover:text-accent transition-colors"
            >
              Voir tout
              <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {featuredCatalogues.map((catalogue, index) => (
              <CatalogueCard key={catalogue.id} catalogue={catalogue} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative rounded-3xl overflow-hidden"
          >
            {/* Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-accent/20" />
            <div className="absolute inset-0 grain" />
            
            {/* Content */}
            <div className="relative px-8 py-16 sm:px-16 sm:py-24 text-center">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="absolute top-8 right-8 opacity-20"
              >
                <Sparkles className="h-24 w-24 text-primary" />
              </motion.div>
              
              <span className="sticker mb-6 inline-block">JOIN THE CLUB</span>
              
              <h2 className="text-display text-4xl sm:text-5xl lg:text-6xl mt-4 max-w-3xl mx-auto">
                PRÊT À INVESTIR<br />
                DANS LA <span className="text-primary text-glow-neon">MUSIQUE</span> ?
              </h2>
              
              <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto">
                Accède en priorité aux nouveaux drops et rejoins une communauté 
                de passionnés qui investissent différemment.
              </p>
              
              <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link
                  href="/pricing"
                  className="group flex items-center gap-3 bg-primary text-primary-foreground px-10 py-4 rounded-full text-lg font-bold hover:shadow-[0_0_40px_rgba(132,204,22,0.4)] transition-all"
                >
                  Découvrir les offres
                  <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
