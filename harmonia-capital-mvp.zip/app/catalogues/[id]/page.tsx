"use client";

import { useState, use } from "react";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { ProgressBar } from "@/components/progress-bar";
import { catalogues } from "@/lib/data";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  Calendar,
  Check,
  Music2,
  Shield,
  TrendingUp,
  Users,
  AlertTriangle,
  Disc3,
  ArrowUpRight,
  Zap,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export default function CatalogueDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const catalogue = catalogues.find((c) => c.id === id);

  if (!catalogue) {
    notFound();
  }

  const [investmentAmount, setInvestmentAmount] = useState(
    catalogue.minimumInvestment
  );

  const simulatedOwnership = (investmentAmount / catalogue.targetAmount) * 100;
  const lastYearRevenue =
    catalogue.historicalRevenue[catalogue.historicalRevenue.length - 1].amount;
  const simulatedAnnualRevenue = (simulatedOwnership / 100) * lastYearRevenue;

  const statusLabels = {
    open: "LIVE",
    funding: "SOON",
    closed: "SOLD",
  };

  const chartData = catalogue.historicalRevenue.map((r) => ({
    year: r.year.toString(),
    revenue: r.amount,
  }));

  return (
    <div className="min-h-screen bg-background grain">
      <Header />

      <main className="pt-28 pb-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          {/* Back link */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <Link
              href="/catalogues"
              className="mb-8 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors group"
            >
              <ArrowLeft className="h-4 w-4 group-hover:-translate-x-1 transition-transform" />
              Retour aux catalogues
            </Link>
          </motion.div>

          <div className="grid gap-8 lg:grid-cols-3">
            {/* Main content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Header */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                className="relative"
              >
                {/* Background visual */}
                <div className="absolute -right-20 -top-10 opacity-10">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                  >
                    <Disc3 className="h-64 w-64 text-primary" />
                  </motion.div>
                </div>

                <div className="mb-4 flex flex-wrap items-center gap-2">
                  <span className="sticker text-[10px]">{catalogue.genre}</span>
                  <span
                    className={cn(
                      "sticker text-[10px]",
                      catalogue.status === "open" && "bg-primary text-primary-foreground",
                      catalogue.status === "funding" && "sticker-purple",
                      catalogue.status === "closed" && "bg-muted text-muted-foreground"
                    )}
                  >
                    {statusLabels[catalogue.status]}
                  </span>
                </div>

                <h1 className="text-display text-4xl sm:text-5xl">
                  {catalogue.name}
                </h1>
                <p className="mt-3 text-xl text-muted-foreground">
                  {catalogue.artist}
                </p>
              </motion.div>

              {/* Description */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="glass-card rounded-2xl p-6"
              >
                <h2 className="text-lg font-bold mb-4">À propos</h2>
                <p className="text-muted-foreground leading-relaxed">
                  {catalogue.description}
                </p>

                <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {catalogue.highlights.map((highlight, index) => (
                    <div
                      key={index}
                      className="flex items-start gap-2 text-sm bg-secondary/30 rounded-lg p-3"
                    >
                      <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
                      <span className="text-sm">{highlight}</span>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Historical revenue chart */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="glass-card rounded-2xl p-6"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-bold">Revenus Historiques</h2>
                  <span className="sticker-purple text-[10px]">DATA VÉRIFIÉ</span>
                </div>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData}>
                      <defs>
                        <linearGradient
                          id="colorRevenue"
                          x1="0"
                          y1="0"
                          x2="0"
                          y2="1"
                        >
                          <stop
                            offset="5%"
                            stopColor="oklch(0.85 0.25 145)"
                            stopOpacity={0.4}
                          />
                          <stop
                            offset="95%"
                            stopColor="oklch(0.85 0.25 145)"
                            stopOpacity={0}
                          />
                        </linearGradient>
                      </defs>
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="oklch(0.22 0.02 280)"
                        vertical={false}
                      />
                      <XAxis
                        dataKey="year"
                        stroke="oklch(0.55 0 0)"
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis
                        stroke="oklch(0.55 0 0)"
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(value) =>
                          `${(value / 1000).toFixed(0)}k€`
                        }
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "oklch(0.1 0.01 280)",
                          border: "1px solid oklch(0.25 0.02 280)",
                          borderRadius: "12px",
                          boxShadow: "0 0 20px rgba(132,204,22,0.1)",
                        }}
                        labelStyle={{ color: "oklch(0.98 0 0)", fontWeight: "bold" }}
                        formatter={(value: number) => [
                          new Intl.NumberFormat("fr-FR", {
                            style: "currency",
                            currency: "EUR",
                          }).format(value),
                          "Revenus",
                        ]}
                      />
                      <Area
                        type="monotone"
                        dataKey="revenue"
                        stroke="oklch(0.85 0.25 145)"
                        strokeWidth={3}
                        fillOpacity={1}
                        fill="url(#colorRevenue)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                <p className="mt-4 text-xs text-muted-foreground">
                  * Les performances passées ne préjugent pas des performances
                  futures.
                </p>
              </motion.div>

              {/* SPV Info */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="glass-card rounded-2xl p-6"
              >
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Shield className="h-7 w-7 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold">Structure SPV</h2>
                    <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                      Ce catalogue est détenu par{" "}
                      <span className="text-primary font-bold">
                        {catalogue.spvName}
                      </span>
                      , une société dédiée qui isole cet actif. Ton
                      investissement représente une participation directe dans cette
                      structure.
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-28 space-y-6">
                {/* Investment progress card */}
                <motion.div
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  className="glass-card rounded-2xl p-6"
                >
                  <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-4">
                    Progression
                  </h3>
                  <ProgressBar
                    value={catalogue.raisedAmount}
                    max={catalogue.targetAmount}
                    variant="neon"
                  />

                  <div className="mt-6 grid grid-cols-2 gap-4">
                    <div className="bg-secondary/30 rounded-xl p-3 text-center">
                      <Music2 className="h-5 w-5 text-primary mx-auto mb-1" />
                      <p className="text-xl font-bold">{catalogue.tracks}</p>
                      <p className="text-[10px] text-muted-foreground uppercase">Titres</p>
                    </div>
                    <div className="bg-secondary/30 rounded-xl p-3 text-center">
                      <TrendingUp className="h-5 w-5 text-primary mx-auto mb-1" />
                      <p className="text-xl font-bold">
                        {new Intl.NumberFormat("fr-FR", {
                          style: "currency",
                          currency: "EUR",
                          notation: "compact",
                        }).format(lastYearRevenue)}
                      </p>
                      <p className="text-[10px] text-muted-foreground uppercase">Rev. 2024</p>
                    </div>
                  </div>
                </motion.div>

                {/* Investment simulation */}
                {catalogue.status !== "closed" && (
                  <motion.div
                    initial={{ opacity: 0, x: 30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 }}
                    className="relative rounded-2xl overflow-hidden"
                  >
                    {/* Gradient border effect */}
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-transparent to-accent/30 rounded-2xl" />
                    <div className="absolute inset-[1px] bg-card rounded-2xl" />
                    
                    <div className="relative p-6">
                      <div className="flex items-center gap-2 mb-4">
                        <Zap className="h-5 w-5 text-primary" />
                        <h3 className="font-bold">Simulation</h3>
                      </div>

                      <div className="mb-4">
                        <label className="mb-2 block text-xs text-muted-foreground uppercase tracking-wider">
                          Montant à investir
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            min={catalogue.minimumInvestment}
                            step={1000}
                            value={investmentAmount}
                            onChange={(e) =>
                              setInvestmentAmount(Number(e.target.value))
                            }
                            className="w-full rounded-xl border border-border bg-secondary/50 py-3 pl-4 pr-12 text-xl font-bold focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                          />
                          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground font-bold">
                            €
                          </span>
                        </div>
                        <p className="mt-1.5 text-[10px] text-muted-foreground">
                          Min: {new Intl.NumberFormat("fr-FR", {
                            style: "currency",
                            currency: "EUR",
                          }).format(catalogue.minimumInvestment)}
                        </p>
                      </div>

                      <div className="space-y-3 rounded-xl bg-secondary/30 p-4">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Part du catalogue</span>
                          <span className="font-bold text-accent">
                            {simulatedOwnership.toFixed(3)}%
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Revenus simulés (2024)*</span>
                          <span className="font-bold text-primary text-glow-neon">
                            {new Intl.NumberFormat("fr-FR", {
                              style: "currency",
                              currency: "EUR",
                            }).format(simulatedAnnualRevenue)}
                          </span>
                        </div>
                      </div>

                      <button
                        className="group mt-4 w-full flex items-center justify-center gap-2 rounded-full bg-primary py-3.5 font-bold text-primary-foreground transition-all hover:shadow-[0_0_30px_rgba(132,204,22,0.4)] disabled:opacity-50 disabled:hover:shadow-none"
                        disabled={investmentAmount < catalogue.minimumInvestment}
                      >
                        Demander à investir
                        <ArrowUpRight className="h-4 w-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                      </button>

                      <div className="mt-4 flex items-start gap-2 text-xs text-muted-foreground">
                        <AlertTriangle className="h-4 w-4 flex-shrink-0 text-accent mt-0.5" />
                        <p>
                          * Simulation basée sur les revenus 2024. Les revenus
                          futurs ne sont pas garantis.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* Key info */}
                <motion.div
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 }}
                  className="glass-card rounded-2xl p-6"
                >
                  <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-4">
                    Infos clés
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-secondary/50 flex items-center justify-center">
                        <Users className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">SPV</p>
                        <p className="text-sm font-bold">{catalogue.spvName}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-secondary/50 flex items-center justify-center">
                        <Calendar className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Distribution</p>
                        <p className="text-sm font-bold">Semestrielle</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
