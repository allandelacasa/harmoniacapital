"use client";

import { useState } from "react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { CatalogueCard } from "@/components/catalogue-card";
import { catalogues } from "@/lib/data";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { Search, SlidersHorizontal, Disc3 } from "lucide-react";

const statusFilters = [
  { value: "all", label: "TOUS" },
  { value: "open", label: "LIVE" },
  { value: "funding", label: "SOON" },
  { value: "closed", label: "SOLD" },
];

const genreFilters = [
  "Tous",
  "Électronique",
  "Jazz",
  "Pop",
  "Hip-Hop",
  "Classique/Film",
];

export default function CataloguesPage() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [genreFilter, setGenreFilter] = useState("Tous");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCatalogues = catalogues.filter((catalogue) => {
    const matchesStatus =
      statusFilter === "all" || catalogue.status === statusFilter;
    const matchesGenre =
      genreFilter === "Tous" || catalogue.genre === genreFilter;
    const matchesSearch =
      searchQuery === "" ||
      catalogue.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      catalogue.artist.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesStatus && matchesGenre && matchesSearch;
  });

  const totalRaised = catalogues.reduce((sum, c) => sum + c.raisedAmount, 0);
  const totalTarget = catalogues.reduce((sum, c) => sum + c.targetAmount, 0);

  return (
    <div className="min-h-screen bg-background grain">
      <Header />

      <main className="pt-28 pb-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-12 relative"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
              className="absolute -right-10 -top-10 opacity-5"
            >
              <Disc3 className="h-48 w-48 text-primary" />
            </motion.div>
            
            <span className="sticker mb-4 inline-block">DROPS</span>
            <h1 className="text-display text-4xl sm:text-5xl lg:text-6xl mt-2">
              CATALOGUES<br />
              <span className="text-primary text-glow-neon">DISPONIBLES</span>
            </h1>
            <p className="mt-6 max-w-xl text-muted-foreground leading-relaxed">
              Explore notre sélection de catalogues musicaux. Chaque catalogue 
              est détenu par un SPV dédié pour une transparence totale.
            </p>
          </motion.div>

          {/* Stats bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-8 grid grid-cols-2 gap-3 md:grid-cols-4"
          >
            {[
              { label: "Catalogues", value: catalogues.length.toString(), accent: false },
              { 
                label: "Capital levé", 
                value: new Intl.NumberFormat("fr-FR", {
                  style: "currency",
                  currency: "EUR",
                  notation: "compact",
                  maximumFractionDigits: 1,
                }).format(totalRaised),
                accent: false 
              },
              { 
                label: "Objectif total", 
                value: new Intl.NumberFormat("fr-FR", {
                  style: "currency",
                  currency: "EUR",
                  notation: "compact",
                  maximumFractionDigits: 1,
                }).format(totalTarget),
                accent: false 
              },
              { 
                label: "Progression", 
                value: `${((totalRaised / totalTarget) * 100).toFixed(0)}%`, 
                accent: true 
              },
            ].map((stat, i) => (
              <div
                key={stat.label}
                className="glass-card rounded-xl p-4 text-center"
              >
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  {stat.label}
                </p>
                <p className={cn(
                  "mt-1 text-2xl font-bold",
                  stat.accent && "text-primary text-glow-neon"
                )}>
                  {stat.value}
                </p>
              </div>
            ))}
          </motion.div>

          {/* Filters */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-8 glass-card rounded-2xl p-4"
          >
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              {/* Search */}
              <div className="relative flex-1 md:max-w-xs">
                <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Rechercher..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full rounded-full border border-border bg-secondary/50 py-2.5 pl-11 pr-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-all"
                />
              </div>

              <div className="flex flex-wrap items-center gap-4">
                {/* Status filter */}
                <div className="flex items-center gap-2">
                  <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
                  <div className="flex gap-1">
                    {statusFilters.map((filter) => (
                      <button
                        key={filter.value}
                        onClick={() => setStatusFilter(filter.value)}
                        className={cn(
                          "rounded-full px-4 py-2 text-xs font-bold transition-all",
                          statusFilter === filter.value
                            ? "bg-primary text-primary-foreground shadow-[0_0_15px_rgba(132,204,22,0.3)]"
                            : "bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80"
                        )}
                      >
                        {filter.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Genre filter */}
                <select
                  value={genreFilter}
                  onChange={(e) => setGenreFilter(e.target.value)}
                  className="rounded-full border border-border bg-secondary/50 px-4 py-2.5 text-sm font-medium focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary cursor-pointer"
                >
                  {genreFilters.map((genre) => (
                    <option key={genre} value={genre}>
                      {genre}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </motion.div>

          {/* Results */}
          {filteredCatalogues.length > 0 ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredCatalogues.map((catalogue, index) => (
                <CatalogueCard key={catalogue.id} catalogue={catalogue} index={index} />
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="glass-card rounded-2xl py-20 text-center"
            >
              <Disc3 className="h-16 w-16 mx-auto text-muted-foreground/30 mb-4" />
              <p className="text-muted-foreground text-lg">
                Aucun catalogue ne correspond à tes critères.
              </p>
              <button
                onClick={() => {
                  setStatusFilter("all");
                  setGenreFilter("Tous");
                  setSearchQuery("");
                }}
                className="mt-4 text-sm text-primary hover:underline"
              >
                Réinitialiser les filtres
              </button>
            </motion.div>
          )}

          {/* Disclaimer */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="mt-12 glass-card rounded-xl p-4 border-accent/20"
          >
            <p className="text-xs text-muted-foreground text-center">
              <span className="text-accent font-bold">Note :</span> Les données de revenus
              présentées sont historiques et ne constituent pas une garantie de
              performance future. Tout investissement comporte des risques.
            </p>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
