"use client";

import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { pricingTiers } from "@/lib/data";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { Check, Crown, Shield, Star, Zap, ArrowRight, Sparkles } from "lucide-react";

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-background grain">
      <Header />

      <main className="pt-28 pb-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto max-w-3xl text-center mb-16"
          >
            <span className="sticker-purple mb-4 inline-block">MEMBERSHIP</span>
            <h1 className="text-display text-4xl sm:text-5xl lg:text-6xl mt-4">
              REJOINS LE<br />
              <span className="text-primary text-glow-neon">CLUB</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground leading-relaxed max-w-xl mx-auto">
              Accède en priorité aux meilleures opportunités d&apos;investissement
              dans les catalogues musicaux. Choisis ton niveau.
            </p>
          </motion.div>

          {/* Pricing cards */}
          <div className="grid gap-6 lg:grid-cols-3">
            {pricingTiers.map((tier, index) => (
              <motion.div
                key={tier.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -8, transition: { duration: 0.2 } }}
                className={cn(
                  "relative rounded-2xl p-8 transition-all",
                  tier.highlighted
                    ? "bg-gradient-to-b from-primary/20 via-card to-card border border-primary/30 shadow-[0_0_40px_rgba(132,204,22,0.15)]"
                    : "glass-card"
                )}
              >
                {tier.highlighted && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="sticker flex items-center gap-1.5">
                      <Star className="h-3 w-3" />
                      POPULAIRE
                    </span>
                  </div>
                )}

                <div className="mb-6">
                  <h3 className="text-2xl font-bold tracking-tight">
                    {tier.name}
                  </h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    {tier.description}
                  </p>
                </div>

                <div className="mb-6">
                  <div className="flex items-baseline gap-2">
                    <span className="text-5xl font-bold">
                      {new Intl.NumberFormat("fr-FR", {
                        style: "currency",
                        currency: "EUR",
                        maximumFractionDigits: 0,
                      }).format(tier.price)}
                    </span>
                    <span className="text-muted-foreground">/{tier.period}</span>
                  </div>
                </div>

                {/* Limits */}
                <div className="mb-6 space-y-2 rounded-xl bg-secondary/30 p-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Max / an</span>
                    <span className="font-bold">{tier.maxInvestmentPerYear}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Max / catalogue</span>
                    <span className="font-bold">{tier.maxInvestmentPerCatalogue}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Deal fee</span>
                    <span className="font-bold text-primary">{tier.dealFee}</span>
                  </div>
                </div>

                <button
                  className={cn(
                    "group mb-8 w-full flex items-center justify-center gap-2 rounded-full py-3.5 font-bold transition-all",
                    tier.highlighted
                      ? "bg-primary text-primary-foreground hover:shadow-[0_0_30px_rgba(132,204,22,0.4)]"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  )}
                >
                  Souscrire
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <ul className="space-y-3">
                  {tier.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-sm">
                      <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>

          {/* Benefits section */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="mt-24"
          >
            <div className="text-center mb-12">
              <span className="sticker mb-4 inline-block">AVANTAGES</span>
              <h2 className="text-display text-3xl sm:text-4xl mt-4">
                POURQUOI <span className="text-accent text-glow-purple">REJOINDRE</span>
              </h2>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[
                {
                  icon: Zap,
                  title: "ACCÈS PRIORITAIRE",
                  desc: "Sois informé en premier des nouvelles opportunités avant leur ouverture publique.",
                },
                {
                  icon: Shield,
                  title: "DUE DILIGENCE",
                  desc: "Accède aux rapports d'audit et d'analyse détaillés sur chaque catalogue.",
                },
                {
                  icon: Crown,
                  title: "ÉVÉNEMENTS VIP",
                  desc: "Participe à des événements privés avec les artistes et experts de l'industrie.",
                },
              ].map((item, i) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="glass-card rounded-2xl p-6 group hover:border-primary/30 transition-all"
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-all mb-4">
                    <item.icon className="h-6 w-6" />
                  </div>
                  <h3 className="text-lg font-bold tracking-tight mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* FAQ */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="mt-24"
          >
            <div className="text-center mb-12">
              <span className="sticker-purple mb-4 inline-block">FAQ</span>
              <h2 className="text-display text-3xl sm:text-4xl mt-4">
                QUESTIONS <span className="text-primary">FRÉQUENTES</span>
              </h2>
            </div>

            <div className="mx-auto max-w-3xl space-y-4">
              {[
                {
                  q: "Comment fonctionne l'investissement dans un catalogue ?",
                  a: "Chaque catalogue est détenu par une société dédiée (SPV). En investissant, tu achètes des parts de cette société et reçois une quote-part des revenus générés par les droits d'auteur.",
                },
                {
                  q: "Quelle est la fréquence des distributions ?",
                  a: "Les revenus sont collectés et distribués aux investisseurs de manière semestrielle. Tu reçois un reporting détaillé avec chaque distribution.",
                },
                {
                  q: "Puis-je revendre mes parts ?",
                  a: "Un marché secondaire est en cours de développement. En attendant, les parts peuvent être cédées de gré à gré avec l'accord de la société de gestion.",
                },
                {
                  q: "Quels sont les risques ?",
                  a: "L'investissement dans des catalogues musicaux comporte des risques : évolution des modes de consommation, baisse des streams, changements réglementaires. Les performances passées ne garantissent pas les performances futures.",
                },
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="glass-card rounded-xl p-6"
                >
                  <h3 className="font-bold mb-3">{item.q}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.a}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Disclaimer */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-16 glass-card rounded-xl p-6 border-accent/20"
          >
            <div className="flex items-start gap-3">
              <Sparkles className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
              <p className="text-sm text-muted-foreground leading-relaxed">
                <span className="text-accent font-bold">Important :</span> L&apos;investissement
                dans des catalogues musicaux comporte des risques significatifs.
                Les revenus passés ne préjugent pas des revenus futurs. Le capital
                investi n&apos;est pas garanti.
              </p>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
