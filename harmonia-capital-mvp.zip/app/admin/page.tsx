"use client";

import { useState } from "react";
import Link from "next/link";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { StatCard } from "@/components/stat-card";
import { ProgressBar } from "@/components/progress-bar";
import { catalogues, mockAdminStats } from "@/lib/data";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import {
  Briefcase,
  Users,
  Music2,
  TrendingUp,
  FileText,
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle,
  Settings,
  BarChart3,
  ArrowUpRight,
  Zap,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const pendingApplications = [
  {
    id: "app-001",
    name: "Sophie Martin",
    email: "sophie.martin@email.com",
    catalogueId: "cat-004",
    amount: 25000,
    date: "2025-01-15",
    status: "pending",
    tier: "Premium",
  },
  {
    id: "app-002",
    name: "Pierre Dubois",
    email: "pierre.dubois@email.com",
    catalogueId: "cat-003",
    amount: 15000,
    date: "2025-01-14",
    status: "pending",
    tier: "Essential",
  },
  {
    id: "app-003",
    name: "Marie Leroy",
    email: "marie.leroy@email.com",
    catalogueId: "cat-005",
    amount: 10000,
    date: "2025-01-13",
    status: "review",
    tier: "Essential",
  },
  {
    id: "app-004",
    name: "Jean Moreau",
    email: "jean.moreau@email.com",
    catalogueId: "cat-001",
    amount: 50000,
    date: "2025-01-12",
    status: "pending",
    tier: "Black",
  },
  {
    id: "app-005",
    name: "Claire Bernard",
    email: "claire.bernard@email.com",
    catalogueId: "cat-004",
    amount: 20000,
    date: "2025-01-11",
    status: "review",
    tier: "Premium",
  },
];

const monthlyData = [
  { month: "Août", aum: 12500000, investors: 720 },
  { month: "Sep", aum: 13200000, investors: 758 },
  { month: "Oct", aum: 13800000, investors: 790 },
  { month: "Nov", aum: 14500000, investors: 815 },
  { month: "Déc", aum: 15200000, investors: 835 },
  { month: "Jan", aum: 15750000, investors: 847 },
];

export default function AdminPage() {
  const [selectedTab, setSelectedTab] = useState<"overview" | "applications" | "catalogues">("overview");

  const getCatalogueName = (id: string) => {
    const catalogue = catalogues.find((c) => c.id === id);
    return catalogue?.name || "Inconnu";
  };

  return (
    <div className="min-h-screen bg-background grain">
      <Header />

      <main className="pt-28 pb-20">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-center"
          >
            <div>
              <div className="mb-2 inline-flex items-center gap-2 sticker-purple text-[10px]">
                <AlertTriangle className="h-3 w-3" />
                DEMO MODE
              </div>
              <h1 className="text-display text-3xl sm:text-4xl">
                ADMIN <span className="text-accent">PANEL</span>
              </h1>
              <p className="mt-2 text-muted-foreground">
                Gère les catalogues, investisseurs et demandes.
              </p>
            </div>
            <button className="flex items-center gap-2 glass-card rounded-full px-5 py-2.5 text-sm font-medium transition-all hover:bg-white/10">
              <Settings className="h-4 w-4" />
              Config
            </button>
          </motion.div>

          {/* Stats */}
          <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <StatCard
              label="AUM"
              value={new Intl.NumberFormat("fr-FR", {
                style: "currency",
                currency: "EUR",
                notation: "compact",
                maximumFractionDigits: 1,
              }).format(mockAdminStats.totalAUM)}
              change={`+${mockAdminStats.monthlyGrowth}% ce mois`}
              changeType="positive"
              icon={<Briefcase className="h-5 w-5" />}
              glowColor="neon"
            />
            <StatCard
              label="Membres"
              value={mockAdminStats.totalInvestors.toString()}
              icon={<Users className="h-5 w-5" />}
              glowColor="purple"
            />
            <StatCard
              label="Catalogues"
              value={mockAdminStats.activeCatalogues.toString()}
              icon={<Music2 className="h-5 w-5" />}
            />
            <StatCard
              label="En attente"
              value={mockAdminStats.pendingApplications.toString()}
              change="À traiter"
              changeType="neutral"
              icon={<FileText className="h-5 w-5" />}
              glowColor="purple"
            />
            <StatCard
              label="Growth"
              value={`+${mockAdminStats.monthlyGrowth}%`}
              change="vs mois précédent"
              changeType="positive"
              icon={<TrendingUp className="h-5 w-5" />}
              glowColor="neon"
            />
          </div>

          {/* Tabs */}
          <div className="mb-6 flex gap-2 overflow-x-auto pb-2">
            {[
              { id: "overview", label: "Overview", icon: BarChart3 },
              { id: "applications", label: `Demandes (${pendingApplications.length})`, icon: FileText },
              { id: "catalogues", label: "Catalogues", icon: Music2 },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id as typeof selectedTab)}
                className={cn(
                  "flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-all whitespace-nowrap",
                  selectedTab === tab.id
                    ? "bg-primary text-primary-foreground shadow-[0_0_20px_rgba(132,204,22,0.3)]"
                    : "glass-card text-muted-foreground hover:text-foreground"
                )}
              >
                <tab.icon className="h-4 w-4" />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab content */}
          {selectedTab === "overview" && (
            <div className="space-y-6">
              {/* Chart */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="glass-card rounded-2xl p-6"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="font-bold">Évolution AUM</h2>
                  <span className="sticker text-[10px]">6 MOIS</span>
                </div>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={monthlyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 280)" vertical={false} />
                      <XAxis dataKey="month" stroke="oklch(0.55 0 0)" fontSize={11} tickLine={false} axisLine={false} />
                      <YAxis stroke="oklch(0.55 0 0)" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(value) => `${(value / 1000000).toFixed(1)}M`} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "oklch(0.1 0.01 280)",
                          border: "1px solid oklch(0.25 0.02 280)",
                          borderRadius: "12px",
                        }}
                        labelStyle={{ color: "oklch(0.98 0 0)", fontWeight: "bold" }}
                        formatter={(value: number) => [
                          new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(value),
                          "AUM",
                        ]}
                      />
                      <Line type="monotone" dataKey="aum" stroke="oklch(0.85 0.25 145)" strokeWidth={3} dot={{ fill: "oklch(0.85 0.25 145)", strokeWidth: 0, r: 4 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </motion.div>

              {/* Recent activity */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="glass-card rounded-2xl overflow-hidden"
              >
                <div className="border-b border-border/50 p-6">
                  <h2 className="font-bold">Activité récente</h2>
                </div>
                <div className="divide-y divide-border/50">
                  {[
                    { icon: CheckCircle, color: "text-primary", bg: "bg-primary/10", title: "Souscription validée", desc: "Pierre Laurent - 30 000€ - Collection Électronique", time: "Il y a 2h" },
                    { icon: FileText, color: "text-accent", bg: "bg-accent/10", title: "Nouvelle demande", desc: "Sophie Martin - 25 000€ - Hip-Hop Urbain", time: "Il y a 5h" },
                    { icon: Users, color: "text-blue-400", bg: "bg-blue-500/10", title: "Nouveau membre Black", desc: "Marc Durand - Abonnement annuel", time: "Il y a 1j" },
                  ].map((item, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.2 + i * 0.05 }}
                      className="flex items-center gap-4 p-4 hover:bg-white/[0.02] transition-colors"
                    >
                      <div className={cn("rounded-full p-2.5", item.bg)}>
                        <item.icon className={cn("h-4 w-4", item.color)} />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-bold">{item.title}</p>
                        <p className="text-xs text-muted-foreground">{item.desc}</p>
                      </div>
                      <span className="text-xs text-muted-foreground">{item.time}</span>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </div>
          )}

          {selectedTab === "applications" && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="glass-card rounded-2xl overflow-hidden"
            >
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border/50">
                      <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Investisseur</th>
                      <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Catalogue</th>
                      <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Montant</th>
                      <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Statut</th>
                      <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/50">
                    {pendingApplications.map((app, i) => (
                      <motion.tr
                        key={app.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.05 }}
                        className="transition-colors hover:bg-white/[0.02]"
                      >
                        <td className="px-6 py-4">
                          <div>
                            <p className="font-bold">{app.name}</p>
                            <p className="text-xs text-muted-foreground">{app.email}</p>
                            <span className="mt-1 inline-block sticker text-[9px] scale-90">{app.tier}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <p className="text-sm font-medium">{getCatalogueName(app.catalogueId)}</p>
                          <p className="text-xs text-muted-foreground">{new Date(app.date).toLocaleDateString("fr-FR")}</p>
                        </td>
                        <td className="px-6 py-4">
                          <p className="font-bold text-lg">
                            {new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(app.amount)}
                          </p>
                        </td>
                        <td className="px-6 py-4">
                          <span className={cn(
                            "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold",
                            app.status === "pending" ? "bg-yellow-500/10 text-yellow-400" : "bg-accent/10 text-accent"
                          )}>
                            <Clock className="h-3 w-3" />
                            {app.status === "pending" ? "En attente" : "En révision"}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <button className="rounded-lg bg-primary/10 p-2.5 text-primary transition-colors hover:bg-primary hover:text-primary-foreground">
                              <CheckCircle className="h-4 w-4" />
                            </button>
                            <button className="rounded-lg bg-red-500/10 p-2.5 text-red-400 transition-colors hover:bg-red-500 hover:text-white">
                              <XCircle className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {selectedTab === "catalogues" && (
            <div className="space-y-4">
              {catalogues.map((catalogue, i) => (
                <motion.div
                  key={catalogue.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="glass-card rounded-2xl p-6"
                >
                  <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="font-bold text-lg">{catalogue.name}</h3>
                        <span className={cn(
                          "sticker text-[9px]",
                          catalogue.status === "open" && "bg-primary text-primary-foreground",
                          catalogue.status === "funding" && "sticker-purple",
                          catalogue.status === "closed" && "bg-muted text-muted-foreground"
                        )}>
                          {catalogue.status === "open" ? "LIVE" : catalogue.status === "funding" ? "SOON" : "SOLD"}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {catalogue.artist} • {catalogue.genre} • {catalogue.tracks} titres
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">SPV: {catalogue.spvName}</p>
                    </div>

                    <div className="w-full md:w-64">
                      <ProgressBar value={catalogue.raisedAmount} max={catalogue.targetAmount} size="sm" variant="neon" />
                    </div>

                    <Link
                      href={`/catalogues/${catalogue.id}`}
                      className="group flex items-center gap-2 glass-card rounded-full px-5 py-2.5 text-sm font-bold hover:bg-white/10 transition-all"
                    >
                      Détails
                      <ArrowUpRight className="h-4 w-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          )}

          {/* Disclaimer */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-8 glass-card rounded-xl p-4 border-accent/20"
          >
            <div className="flex items-start gap-3">
              <Zap className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
              <p className="text-sm text-muted-foreground">
                <span className="text-accent font-bold">Demo mode :</span> Cette page d&apos;administration
                est une démonstration avec des données fictives. Aucune action n&apos;est réellement effectuée.
              </p>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
