"use client";

import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface ProgressBarProps {
  value: number;
  max: number;
  className?: string;
  showLabel?: boolean;
  size?: "sm" | "md" | "lg";
  variant?: "default" | "neon" | "purple";
}

export function ProgressBar({
  value,
  max,
  className,
  showLabel = true,
  size = "md",
  variant = "default",
}: ProgressBarProps) {
  const percentage = Math.min((value / max) * 100, 100);

  const sizeClasses = {
    sm: "h-1.5",
    md: "h-2.5",
    lg: "h-3.5",
  };

  const barColors = {
    default: "bg-primary",
    neon: "bg-gradient-to-r from-primary to-[oklch(0.7_0.2_145)]",
    purple: "bg-gradient-to-r from-accent to-[oklch(0.6_0.25_300)]",
  };

  return (
    <div className={cn("w-full", className)}>
      {showLabel && (
        <div className="mb-2 flex items-center justify-between text-xs">
          <span className="text-muted-foreground font-medium">
            {new Intl.NumberFormat("fr-FR", {
              style: "currency",
              currency: "EUR",
              maximumFractionDigits: 0,
            }).format(value)}
          </span>
          <span className="font-bold text-primary text-glow-neon">
            {percentage.toFixed(0)}%
          </span>
        </div>
      )}
      <div
        className={cn(
          "w-full overflow-hidden rounded-full bg-secondary/50",
          sizeClasses[size]
        )}
      >
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
          className={cn(
            "h-full rounded-full relative",
            barColors[variant]
          )}
        >
          {/* Glow effect */}
          <div className="absolute inset-0 blur-sm bg-inherit opacity-50" />
        </motion.div>
      </div>
      {showLabel && (
        <div className="mt-1.5 text-right text-xs text-muted-foreground">
          Objectif:{" "}
          <span className="font-medium text-foreground">
            {new Intl.NumberFormat("fr-FR", {
              style: "currency",
              currency: "EUR",
              maximumFractionDigits: 0,
            }).format(max)}
          </span>
        </div>
      )}
    </div>
  );
}
