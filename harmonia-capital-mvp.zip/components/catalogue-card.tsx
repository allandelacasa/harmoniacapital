"use client";

import Link from "next/link";
import { type Catalogue } from "@/lib/data";
import { ProgressBar } from "./progress-bar";
import { cn } from "@/lib/utils";
import { Music2, TrendingUp, Disc3, ArrowUpRight } from "lucide-react";
import { motion } from "framer-motion";

interface CatalogueCardProps {
  catalogue: Catalogue;
  className?: string;
  index?: number;
}

export function CatalogueCard({ catalogue, className, index = 0 }: CatalogueCardProps) {
  const statusLabels = {
    open: "LIVE",
    funding: "SOON",
    closed: "SOLD",
  };

  const statusColors = {
    open: "bg-primary text-primary-foreground",
    funding: "bg-accent text-accent-foreground",
    closed: "bg-muted text-muted-foreground",
  };

  const lastYearRevenue =
    catalogue.historicalRevenue[catalogue.historicalRevenue.length - 1];
  const previousYearRevenue =
    catalogue.historicalRevenue[catalogue.historicalRevenue.length - 2];
  const revenueGrowth = previousYearRevenue
    ? (
        ((lastYearRevenue.amount - previousYearRevenue.amount) /
          previousYearRevenue.amount) *
        100
      ).toFixed(1)
    : "0";

  return (
    <Link href={`/catalogues/${catalogue.id}`} className="block group">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: index * 0.1 }}
        whileHover={{ y: -8, transition: { duration: 0.2 } }}
        className={cn(
          "glass-card rounded-2xl overflow-hidden transition-all duration-300",
          "hover:shadow-[0_0_40px_rgba(132,204,22,0.1)]",
          className
        )}
      >
        {/* Header with visual */}
        <div className="relative h-40 overflow-hidden bg-gradient-to-br from-secondary via-card to-background">
          {/* Background pattern */}
          <div className="absolute inset-0 opacity-30">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <Disc3 className="h-32 w-32 text-primary/20 animate-[spin_20s_linear_infinite]" />
            </div>
          </div>
          
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
          
          {/* Status badge */}
          <div className="absolute right-4 top-4">
            <span
              className={cn(
                "sticker text-[10px]",
                catalogue.status === "open" && "bg-primary text-primary-foreground",
                catalogue.status === "funding" && "sticker-purple",
                catalogue.status === "closed" && "bg-muted text-muted-foreground"
              )}
            >
              {statusLabels[catalogue.status]}
            </span>
          </div>

          {/* Genre tag */}
          <div className="absolute left-4 top-4">
            <span className="text-[10px] font-bold uppercase tracking-wider text-primary bg-primary/10 px-2 py-1 rounded">
              {catalogue.genre}
            </span>
          </div>
        </div>

        <div className="p-5">
          {/* Title and artist */}
          <h3 className="text-lg font-bold tracking-tight group-hover:text-primary transition-colors line-clamp-1">
            {catalogue.name}
          </h3>
          <p className="mt-1 text-sm text-muted-foreground">
            {catalogue.artist}
          </p>

          {/* Stats row */}
          <div className="mt-4 flex items-center gap-4 text-sm">
            <div className="flex items-center gap-1.5">
              <Music2 className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium">{catalogue.tracks}</span>
              <span className="text-muted-foreground">titres</span>
            </div>
            <div className="flex items-center gap-1.5">
              <TrendingUp className="h-4 w-4 text-primary" />
              <span className="font-medium text-primary">+{revenueGrowth}%</span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mt-4">
            <ProgressBar
              value={catalogue.raisedAmount}
              max={catalogue.targetAmount}
              size="sm"
              showLabel={false}
            />
            <div className="mt-2 flex items-center justify-between text-xs">
              <span className="text-muted-foreground">
                {((catalogue.raisedAmount / catalogue.targetAmount) * 100).toFixed(0)}% financé
              </span>
              <span className="font-medium">
                {new Intl.NumberFormat("fr-FR", {
                  style: "currency",
                  currency: "EUR",
                  maximumFractionDigits: 0,
                }).format(catalogue.targetAmount)}
              </span>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-4 pt-4 border-t border-border/50 flex items-center justify-between">
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                Min. invest
              </p>
              <p className="text-lg font-bold">
                {new Intl.NumberFormat("fr-FR", {
                  style: "currency",
                  currency: "EUR",
                  maximumFractionDigits: 0,
                }).format(catalogue.minimumInvestment)}
              </p>
            </div>
            <div className="flex items-center gap-2 text-primary opacity-0 group-hover:opacity-100 transition-opacity">
              <span className="text-sm font-medium">Voir</span>
              <ArrowUpRight className="h-4 w-4" />
            </div>
          </div>
        </div>
      </motion.div>
    </Link>
  );
}
