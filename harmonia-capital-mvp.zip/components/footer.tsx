import Link from "next/link";
import { Disc3, Instagram, Twitter, Linkedin, ArrowUpRight } from "lucide-react";

const footerLinks = {
  plateforme: [
    { href: "/catalogues", label: "Catalogues" },
    { href: "/pricing", label: "Club Harmonia" },
    { href: "/dashboard", label: "Dashboard" },
  ],
  legal: [
    { href: "#", label: "CGU" },
    { href: "#", label: "Confidentialité" },
    { href: "#", label: "Mentions légales" },
  ],
  resources: [
    { href: "#", label: "FAQ" },
    { href: "#", label: "Blog" },
    { href: "#", label: "Contact" },
  ],
};

const socialLinks = [
  { href: "#", icon: Instagram, label: "Instagram" },
  { href: "#", icon: Twitter, label: "Twitter" },
  { href: "#", icon: Linkedin, label: "LinkedIn" },
];

export function Footer() {
  return (
    <footer className="relative border-t border-border/50 mt-20">
      {/* Gradient glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />

      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-12 lg:grid-cols-5">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-3 mb-6 group">
              <div className="relative">
                <Disc3 className="h-10 w-10 text-primary transition-transform duration-500 group-hover:rotate-180" />
              </div>
              <span className="text-2xl font-bold tracking-tight">
                HARMONIA
              </span>
            </Link>
            <p className="text-muted-foreground max-w-sm mb-6 text-sm leading-relaxed">
              Le club exclusif d&apos;investissement dans les catalogues musicaux.
              Rejoignez une communauté passionnée par la musique et l&apos;investissement alternatif.
            </p>
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className="p-2.5 rounded-full bg-secondary hover:bg-primary hover:text-primary-foreground transition-all group"
                  aria-label={social.label}
                >
                  <social.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-primary mb-4">
              Plateforme
            </h4>
            <ul className="space-y-3">
              {footerLinks.plateforme.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center gap-1 group"
                  >
                    {link.label}
                    <ArrowUpRight className="h-3 w-3 opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-primary mb-4">
              Ressources
            </h4>
            <ul className="space-y-3">
              {footerLinks.resources.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center gap-1 group"
                  >
                    {link.label}
                    <ArrowUpRight className="h-3 w-3 opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-primary mb-4">
              Légal
            </h4>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center gap-1 group"
                  >
                    {link.label}
                    <ArrowUpRight className="h-3 w-3 opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-16 pt-8 border-t border-border/50">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-muted-foreground">
              &copy; {new Date().getFullYear()} Harmonia Capital. Tous droits réservés.
            </p>
            <div className="glass-card px-4 py-2 rounded-full">
              <p className="text-xs text-muted-foreground">
                Les performances passées ne garantissent pas les résultats futurs.
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
